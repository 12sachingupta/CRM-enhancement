<x-app-layout pagename="Companies">
    <livewire:companies.index/>
</x-app-layout>
