<x-app-layout pagename="Edit Company">
    <livewire:companies.edit :company="$company"/>
</x-app-layout>
