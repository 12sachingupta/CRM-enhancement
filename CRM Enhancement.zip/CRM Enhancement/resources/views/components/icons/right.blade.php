<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" {{ $attributes }}>
    <polygon
        points="12.95 10.707 13.657 10 8 4.343 6.586 5.757 10.828 10 6.586 14.243 8 15.657 12.95 10.707"></polygon>
</svg>
