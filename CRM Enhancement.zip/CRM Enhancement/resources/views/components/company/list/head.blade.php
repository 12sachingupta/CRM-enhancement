<tr class="text-left font-bold">
    <th class="pl-4 pr-2 pt-6 pb-4 w-6">
        &nbsp;
    </th>
{{--    <th class="px-1 pt-6 pb-4 w-6">View</th>--}}
    <th class="px-2 pt-6 pb-4 w-6">Edit</th>
    <th class="px-6 pt-6 pb-4">Company Name</th>
    <th class="px-6 pt-6 pb-4">City</th>
    <th class="px-6 pt-6 pb-4">Country</th>
    <th class="px-6 pt-6 pb-4">Phone</th>
    <th class="pl-1 pr-4 pt-6 pb-4 w-6 text-red-500">Delete</th>
</tr>
