<tr class="hover:bg-gray-100 focus-within:bg-gray-100">
    <td class="border-t p-4" colspan="4">
        <p>No company added yet.</p>
    </td>
</tr>
